package br.com.seuprojeto.dto;

public class ClienteRequestDTO {
    private String nome;
    private String email;
    private String documento;

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }
}
