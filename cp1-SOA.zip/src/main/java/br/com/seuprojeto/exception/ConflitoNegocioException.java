package br.com.seuprojeto.exception;

public class ConflitoNegocioException extends RuntimeException {
    public ConflitoNegocioException(String msg) { super(msg); }
}
