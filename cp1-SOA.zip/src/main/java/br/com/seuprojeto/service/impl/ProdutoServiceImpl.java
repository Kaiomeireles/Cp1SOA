package br.com.seuprojeto.service.impl;

import br.com.seuprojeto.domain.Produto;
import br.com.seuprojeto.dto.ProdutoRequestDTO;
import br.com.seuprojeto.dto.ProdutoResponseDTO;
import br.com.seuprojeto.exception.RecursoNaoEncontradoException;
import br.com.seuprojeto.service.ProdutoService;
import br.com.seuprojeto.repository.ProdutoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ProdutoServiceImpl implements ProdutoService {

    private final ProdutoRepository repo;

    public ProdutoServiceImpl(ProdutoRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<ProdutoResponseDTO> listar(String categoria, Boolean ativo) {
        return repo.findAll().stream()
                .filter(p -> categoria == null || (p.getCategoria() != null && p.getCategoria().equalsIgnoreCase(categoria)))
                .filter(p -> ativo == null || (p.getAtivo() != null && p.getAtivo().equals(ativo)))
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public ProdutoResponseDTO buscarPorId(Long id) {
        Produto p = repo.findById(id).orElseThrow(() -> new RecursoNaoEncontradoException("produto não encontrado"));
        return toResponse(p);
    }

    @Override
    public ProdutoResponseDTO criar(ProdutoRequestDTO dto) {
        if (dto.getNome() == null || dto.getNome().isBlank()) {
            throw new IllegalArgumentException("nome é obrigatório");
        }
        if (dto.getPreco() == null || dto.getPreco().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("preco deve ser maior que 0");
        }
        Produto novo = new Produto(null, dto.getNome(), dto.getPreco(), dto.getCategoria(), dto.getDescricao(),
                dto.getAtivo() == null ? Boolean.TRUE : dto.getAtivo());
        novo = repo.save(novo);
        return toResponse(novo);
    }

    @Override
    public void atualizar(Long id, ProdutoRequestDTO dto) {
        Produto p = repo.findById(id).orElseThrow(() -> new RecursoNaoEncontradoException("produto não encontrado"));
        if (dto.getNome() != null) p.setNome(dto.getNome());
        if (dto.getPreco() != null) {
            if (dto.getPreco().compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("preco deve ser maior que 0");
            }
            p.setPreco(dto.getPreco());
        }
        if (dto.getCategoria() != null) p.setCategoria(dto.getCategoria());
        if (dto.getDescricao() != null) p.setDescricao(dto.getDescricao());
        if (dto.getAtivo() != null) p.setAtivo(dto.getAtivo());
        repo.save(p);
    }

    @Override
    public void excluir(Long id) {
        if (!repo.existsById(id)) throw new RecursoNaoEncontradoException("produto não encontrado");
        repo.deleteById(id);
    }

    private ProdutoResponseDTO toResponse(Produto p) {
        ProdutoResponseDTO r = new ProdutoResponseDTO();
        r.setId(p.getId());
        r.setNome(p.getNome());
        r.setPreco(p.getPreco());
        r.setCategoria(p.getCategoria());
        r.setDescricao(p.getDescricao());
        r.setAtivo(p.getAtivo());
        return r;
    }
}
