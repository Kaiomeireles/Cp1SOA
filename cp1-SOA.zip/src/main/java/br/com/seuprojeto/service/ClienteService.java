package br.com.seuprojeto.service;

import br.com.seuprojeto.dto.ClienteRequestDTO;
import br.com.seuprojeto.dto.ClienteResponseDTO;
import java.util.List;

public interface ClienteService {
    List<ClienteResponseDTO> listar(String nome, String email);
    ClienteResponseDTO buscarPorId(Long id);
    ClienteResponseDTO criar(ClienteRequestDTO dto);
    void atualizar(Long id, ClienteRequestDTO dto);
    void excluir(Long id);
}
