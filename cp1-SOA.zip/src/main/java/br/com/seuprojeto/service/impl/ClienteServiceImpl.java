package br.com.seuprojeto.service.impl;

import br.com.seuprojeto.domain.Cliente;
import br.com.seuprojeto.dto.ClienteRequestDTO;
import br.com.seuprojeto.dto.ClienteResponseDTO;
import br.com.seuprojeto.exception.ConflitoNegocioException;
import br.com.seuprojeto.exception.RecursoNaoEncontradoException;
import br.com.seuprojeto.repository.ClienteRepository;
import br.com.seuprojeto.service.ClienteService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class ClienteServiceImpl implements ClienteService {

    private final ClienteRepository repo;

    public ClienteServiceImpl(ClienteRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<ClienteResponseDTO> listar(String nome, String email) {
        // Lista simples; filtros opcionais podem ser aplicados manualmente aqui
        return repo.findAll().stream()
                .filter(c -> nome == null || c.getNome().toLowerCase().contains(nome.toLowerCase()))
                .filter(c -> email == null || c.getEmail().equalsIgnoreCase(email))
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public ClienteResponseDTO buscarPorId(Long id) {
        Cliente c = repo.findById(id).orElseThrow(() -> new RecursoNaoEncontradoException("cliente não encontrado"));
        return toResponse(c);
    }

    @Override
    public ClienteResponseDTO criar(ClienteRequestDTO dto) {
        if (dto.getNome() == null || dto.getNome().isBlank()) {
            throw new IllegalArgumentException("nome é obrigatório");
        }
        if (dto.getEmail() == null || dto.getEmail().isBlank()) {
            throw new IllegalArgumentException("email é obrigatório");
        }
        if (dto.getDocumento() == null || dto.getDocumento().isBlank()) {
            throw new IllegalArgumentException("documento é obrigatório");
        }
        repo.findByEmail(dto.getEmail()).ifPresent(c -> { throw new ConflitoNegocioException("email já cadastrado"); });
        Cliente novo = new Cliente(null, dto.getNome(), dto.getEmail(), dto.getDocumento());
        novo = repo.save(novo);
        return toResponse(novo);
    }

    @Override
    public void atualizar(Long id, ClienteRequestDTO dto) {
        Cliente c = repo.findById(id).orElseThrow(() -> new RecursoNaoEncontradoException("cliente não encontrado"));
        if (dto.getNome() != null) c.setNome(dto.getNome());
        if (dto.getEmail() != null) {
            // se mudou o e-mail, verificar duplicidade
            repo.findByEmail(dto.getEmail())
                .filter(outro -> !outro.getId().equals(id))
                .ifPresent(outro -> { throw new ConflitoNegocioException("email já cadastrado"); });
            c.setEmail(dto.getEmail());
        }
        if (dto.getDocumento() != null) c.setDocumento(dto.getDocumento());
        repo.save(c);
    }

    @Override
    public void excluir(Long id) {
        if (!repo.existsById(id)) throw new RecursoNaoEncontradoException("cliente não encontrado");
        repo.deleteById(id);
    }

    private ClienteResponseDTO toResponse(Cliente c) {
        ClienteResponseDTO r = new ClienteResponseDTO();
        r.setId(c.getId());
        r.setNome(c.getNome());
        r.setEmail(c.getEmail());
        r.setDocumento(c.getDocumento());
        return r;
    }
}
