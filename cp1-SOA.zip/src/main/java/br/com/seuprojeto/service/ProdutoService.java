package br.com.seuprojeto.service;

import br.com.seuprojeto.dto.ProdutoRequestDTO;
import br.com.seuprojeto.dto.ProdutoResponseDTO;
import java.util.List;

public interface ProdutoService {
    List<ProdutoResponseDTO> listar(String categoria, Boolean ativo);
    ProdutoResponseDTO buscarPorId(Long id);
    ProdutoResponseDTO criar(ProdutoRequestDTO dto);
    void atualizar(Long id, ProdutoRequestDTO dto);
    void excluir(Long id);
}
